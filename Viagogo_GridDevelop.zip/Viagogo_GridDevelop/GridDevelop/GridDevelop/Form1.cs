﻿//This program randomly generates events in various location and computes the nearest top 5 events for a
//given user's location

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GridDevelop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //If the random generation has created multiple events at the same location then the function
        //would find it and replace with the next available location.
        public static void CheckInSeedData(int iXCoordinate, int iYCoordinate, int iPointer, int[,] SeedData, int[,] grid)
        {
            Random r = new Random();//pseudo number random generator
            for (int i = 0; i < iPointer; i++)
            {
                if (SeedData[i, 0] == iXCoordinate && SeedData[i, 1] == iYCoordinate)
                {
                    int iLoopExit = 0;//used as a flag bit to exit loop
                    for (int rows = 0; rows < 20; rows++)
                    {
                        for (int cols = 0; cols < 20; cols++)
                        {
                            if (grid[rows, cols] == 0)
                            {
                                grid[rows, cols] = 1;
                                SeedData[i, 0] = rows - 10;
                                SeedData[i, 1] = cols - 10;
                                iLoopExit = 1;
                                break;
                            }
                        }
                        if (iLoopExit == 1)
                            break;
                    }
                }
            }
        }
        public static void Seed_Random_Generate(int[,] SeedData, int iPointer, int[,] grid)
        {
            Random rnd = new Random();
            int iXCoordinate = 0;
            int iYCoordinate = 0;
            //if else conditions are used to increase the randomness and to make the data set different
            if (iPointer % 2 == 0)
            {
                iXCoordinate = rnd.Next(-100, 100) % 10;
                iYCoordinate = rnd.Next(-100, 100) % 10;
            }
            else if (iPointer % 3 == 0)
            {
                iXCoordinate = rnd.Next(-10, 10);
                iYCoordinate = rnd.Next(-10, 10);
            }
            else
            {
                iXCoordinate = rnd.Next(-100, 100) % 10;
                iYCoordinate = rnd.Next(-10, 10);
            }
            SeedData[iPointer, 0] = iXCoordinate;
            SeedData[iPointer, 1] = iYCoordinate;
            grid[iXCoordinate + 10, iYCoordinate + 10] = 1;
            CheckInSeedData(iXCoordinate, iYCoordinate, iPointer, SeedData, grid);//To relocate events at the same location
            SeedData[iPointer, 2] = iPointer + 1;//To give each event a unique identifier
            int iTickets = 0, iPrice = 0;
            //Randomly generate Tickets for each event and their Price
            if (iPointer % 3 == 0)
            {
                Random tic = new Random();
                Random p = new Random();
                iTickets = tic.Next(555) * (iPointer % 10);
                iPrice = p.Next(100) * (iPointer % 10);

            }
            else if (iPointer % 5 == 0)
            {
                Random tic = new Random();
                Random p = new Random();
                iTickets = tic.Next(55);
                iTickets = iTickets * 10;
                iPrice = p.Next(7);
                iPrice = iPrice * (iPointer + iPointer % 10);

            }
            else
            {
                Random tic = new Random();
                Random p = new Random();
                iTickets = tic.Next(55);
                iTickets = iTickets * iPointer;
                iPrice = p.Next(12);
                iPrice = iPrice * iPointer;
            }
            SeedData[iPointer, 3] = iTickets;
            //One of the criterias to be met
            if (iPrice == 0)
            {
                iPrice = 6;
            }
            SeedData[iPointer, 4] = iPrice;
        }
        //To find the top 5 close by events
        public static void Find_Top(int iXCoordinate, int iYCoordinate, int[,] SeedData, int[,] result, int[,] manhattan, int iEventSize, int[,] finaldist,int iTopMost)
        {
            int index1 = -1;//it will indicate the index of the highest distance among the least5
            int index2 = -1;//it will indicate the index of the event to be inserted in final result
            for (int i = 0; i < iEventSize; i++)
            {
                int iDistance = Math.Abs(iXCoordinate - SeedData[i, 0]) + Math.Abs(iYCoordinate - SeedData[i, 1]);//finding the manhattan distance
                finaldist[0, i] = iDistance;//storing the distance of all the events
                int iHighest = 0;
                int f = 0;
                //to find the highest distance in manhattan
                for (int j = 0; j < iTopMost; j++)
                {
                    if (manhattan[0, j] > iHighest)
                    {
                        int temp = iHighest;
                        iHighest = manhattan[0, j];
                        // manhattan[0, j] = temp;
                        index1 = j;//index of highest distance among manhattan
                        f = 1;
                    }
                }
                if (f == 1)
                {
                    if (iDistance < iHighest)
                    {
                        index2 = i;//index of the current distance since it is less than the highest distance among the lowest 5
                        manhattan[0, index1] = iDistance;
                        f = 2;
                    }
                }
                if (f == 2)
                {
                    result[0, index1] = index2 + 1;//to store the event number of least distance
                }

            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //This function will retrieve the data set/frame of the initially generated seed data
        public static void GetMeSeedData(int[,] SeedData, int iEventSize)
        {
            string sPath = System.IO.Directory.GetCurrentDirectory() + "\\SeedData.txt";
            using (StreamReader sr = new StreamReader(sPath))
            {
                string sLine = sr.ReadToEnd();
                string[] events = sLine.Split(' ');
                int entries = iEventSize;
                int index = 0;
                for (int i = 0; i < entries; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        SeedData[i, j] = Int32.Parse(events[index++]);//converts string to integer
                    }
                }
                sr.Close();
            }
        }
        //This function returns the total number of events available
        public static int GetMesEventNumber()
        {
            string sPath = System.IO.Directory.GetCurrentDirectory() + "\\sEventNumber.txt";
            using (StreamReader sr = new StreamReader(sPath))
            {
                string sLine = sr.ReadToEnd();
                string[] events = sLine.Split('\n');
                int entries = Int32.Parse(events[0]);
                sr.Close();
                return entries;
            }

        }
        //If the user is running the application for the first time then this function will store the random seed data for further runs
        public static void WriteFile(int[,] SeedData, int iEventSize)
        {
            string sPath = System.IO.Directory.GetCurrentDirectory() + "\\SeedData.txt";
            string sPath1 = System.IO.Directory.GetCurrentDirectory() + "\\sEventNumber.txt";

            if (!File.Exists(sPath))
            {
                using (StreamWriter swr = File.CreateText(sPath))//creates a new file
                {
                    string sOutput = "";
                    for (int i = 0; i < iEventSize; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            sOutput = sOutput + SeedData[i, j].ToString() + " ";
                        }
                    }
                    swr.WriteLine(sOutput);
                    swr.Close();
                }
            }
            if (!File.Exists(sPath1))
            {
                using (StreamWriter swr = File.CreateText(sPath1))
                {
                    swr.WriteLine(iEventSize.ToString());
                    swr.Close();
                }
            }
        }
        //The flowwing function sorts the distance in ascending order and maps it to the correct event
        public static void SortInAscending(int[,] result, int[,] manhattan,int iTopMost)
        {
            for (int i = 0; i < iTopMost-1; i++)
            {
                for (int j = i + 1; j < iTopMost; j++)
                {
                    if (manhattan[0, i] > manhattan[0, j])
                    {
                        int iTemp = manhattan[0, i];
                        manhattan[0, i] = manhattan[0, j];
                        manhattan[0, j] = iTemp;
                        iTemp = result[0, i];
                        result[0, i] = result[0, j];
                        result[0, j] = iTemp;
                    }
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Working";
            string sTime = DateTime.Today.ToLongDateString() + " " + DateTime.Now.ToLongTimeString();
            toolStripStatusLabel2.Text = sTime;
            // MessageBox.Show(toolStripStatusLabel2.Text);
            try
            {
                if (comboBox1.Text.Count() < 1 || comboBox2.Text.Count() < 1)
                {
                    toolStripStatusLabel1.Text = "Error";
                    MessageBox.Show("Please select coordinates!");
                    toolStripStatusLabel1.Text = "Ready";
                    return;//closes the application since error state is reached;
                }
            }
            catch
            {
                MessageBox.Show("Make coordinate Selections!");
                return;
            }
            Random rnd1 = new Random();
            string sPath = System.IO.Directory.GetCurrentDirectory() + "\\SeedData.txt";//sPathname which stores the data set
            int iEventSize = 5;// intialization of number of events with minimum value
            int iFwrite = 0;//This bit will indicate whether a user is running it for the first time or is checking at different location
            int[,] grid = new int[20, 20];// total number of available locations
            if (File.Exists(sPath) == true)//the user has run the application before
            {
                iEventSize = GetMesEventNumber();
                iFwrite = 1;//This will indicate to the program that we do not need to generate the seed data again
            }
            else
            {
                iEventSize = rnd1.Next(5, 100);

            }
            int[,] SeedData = new int[iEventSize, 5];// data frame which consits of the events and their properties 
            if (File.Exists(sPath) == true)
            {
                GetMeSeedData(SeedData, iEventSize);
            }
            else
            {
                for (int i = 0; i < iEventSize; i++)
                    Seed_Random_Generate(SeedData, i, grid);//will generate the data frame
            }
            if (iFwrite == 0)
            {
                WriteFile(SeedData, iEventSize);
            }
            //Console.WriteLine("Enter iYCoordinateour coordinates\n");
            string sInput = comboBox1.Text + "," + comboBox2.Text;//will read the coordinates from the textBox
            string[] coord = sInput.Split(',');// string array containing the coordinates of user's location
            int iXCoordinate = Int32.Parse(coord[0]);
            int iYCoordinate = Int32.Parse(coord[1]);
            int iTopEvents = 5;// Number of top events user need
            int[,] result = new int[1, iTopEvents];// will store the top 5 closest event numbers
            int[,] manhattan = new int[1, iTopEvents];// will store the distance of the closest top 5 events
            int iValue = 1000;//max value that the distance can hold
            for (int i = 0; i < iTopEvents; i++)
            {
                manhattan[0, i] = iValue++;
            }
            int[,] finaldist = new int[1, iEventSize];//stores distance of all events form user's location
            Find_Top(iXCoordinate, iYCoordinate, SeedData, result, manhattan, iEventSize, finaldist,iTopEvents);
            for(int i=0;i<iTopEvents;i++)
            {
                if(result[0,i]==0)
                {
                    MessageBox.Show("Exceeds maximum distance!");
                    return;
                }
            }
            string sOutput = "Closest Event to(" + iXCoordinate.ToString() + "," + iYCoordinate.ToString() + "):\r\n\r\n"; //contains the required sOutput string of all the 5 events with least distance and iPrices of iTickets
            SortInAscending(result, manhattan,iTopEvents);
            for (int i = 0; i < 5; i++)
            {
                string sEventNumber = "";
                if (result[0, i] < 100 && result[0, i] > 9)
                {
                    sEventNumber = "0" + result[0, i].ToString();
                }
                else if (result[0, i] < 10)
                {
                    sEventNumber = "00" + result[0, i].ToString();
                }
                else
                {
                    sEventNumber = result[0, i].ToString();
                }
                string sTicketPrice = "";
                if (SeedData[result[0, i] - 1, 4] < 10)
                {
                    sTicketPrice = "00" + SeedData[result[0, i] - 1, 4].ToString();
                }
                else if (SeedData[result[0, i] - 1, 4] < 100)
                {
                    sTicketPrice = "0" + SeedData[result[0, i] - 1, 4].ToString();
                }
                else
                {
                    sTicketPrice = SeedData[result[0, i] - 1, 4].ToString();
                }
                sOutput = sOutput + "Event " + sEventNumber + " - $";
                sOutput = sOutput + sTicketPrice + ", Distance ";
                sOutput = sOutput + manhattan[0, i].ToString() + "\r\n";
            }
            textBox3.Text = sOutput;
            toolStripStatusLabel1.Text = "Last Run:";
            //for (int i = 0; i < n; i++)
            //  Console.WriteLine(i + "  " + finaldist[0, i]);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sPath = System.IO.Directory.GetCurrentDirectory() + "\\SeedData.txt";
            string sPath1 = System.IO.Directory.GetCurrentDirectory() + "\\sEventNumber.txt";
            //Since the user is closing the application, we need to delete all the temporary files
            try
            {
                File.Delete(sPath);
                File.Delete(sPath1);
            }
            catch { }
            toolStripStatusLabel1.Text = "Exiting";
            System.Windows.Forms.Application.Exit();//closes the application
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Convert.ToInt32(e.KeyChar) == 13)
                button1_Click(this, new EventArgs());

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void statusStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel2_LocationChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Add("1");
        }

        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int min = -10;
            int items = 20;
            if (comboBox1.Items.Count != items + 1)
            {
                for (int i = 0; i <= items; i++)
                    comboBox1.Items.Add(min++);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_MouseClick(object sender, MouseEventArgs e)
        {
            int min = -10;
            int items = 20;
            if (comboBox2.Items.Count!= items + 1)
            {     for (int i = 0; i <= items; i++)
                    comboBox2.Items.Add(min++);
            }
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void comboBox2_MouseClick_1(object sender, MouseEventArgs e)
        {
            
            int min = -10;
            int items = 20;
            comboBox2.Items.Clear();
            for (int i = 0; i <= items; i++)
                comboBox2.Items.Add(min++);
        }

        private void comboBox1_MouseClick_1(object sender, MouseEventArgs e)
        {
            int min = -10;
            int items = 20;
            comboBox1.Items.Clear();
            for (int i = 0; i <= items; i++)
                comboBox1.Items.Add(min++);
        }
    }
}
